use IO::File;


use Cwd;
 my $dir = shift;   #注意修改
  #$dir = getcwd; 
#mkdir "$dir/result" unless (-e result);  注意修改
&funall();
sub funall(){
	 for my $p("all"){    	#zhihou   zai  add "ne"  
    
	   	    my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
	   while(my $line1=<$in1>){
          chomp $line1;
          #注意修改 每读取predict_PDB_SEQ一行注意清除临时文件 同时清空result文件夹
          my @a=split/\s+/,$line1;
           $m_in=$a[0];
          system("rm -rf $dir/output\_$a[1]\_$a[2]");  #windows删除 system("rd /s /q output\_$a[1]\_$a[2]"); #删除非空文件夹
          system("rm -rf $dir/result\_$a[0]\_$a[1]\_$a[2]\_$a[4]");  #windows删除 system("rd /s /q result\_$a[0]\_$a[1]\_$a[2]\_$a[4]");
          system("mkdir $dir/output\_$a[1]\_$a[2]");#注意修改
          system("mkdir $dir/result\_$a[0]\_$a[1]\_$a[2]\_$a[4]");#注意修改
            &funall_cal($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
           &andrew_10_cluster($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);  #注意修改
            &funallhy($line1);
&residue_type($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&net($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_total_side_rel($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_total_side_abs($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_non_polar_rel($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_non_polar_abs($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_main_chain_rel($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_main_chain_abs($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_all_polar_rel($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_all_polar_abs($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_all_atom_rel($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&nac_all_atom_abs($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&ex($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&DSSP_tco($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&DSSP_ss($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&DSSP_psi($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&DSSP_phi($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&DSSP_kappa($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&DSSP_alpha($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&DSSP_acc($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&diso($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&ched_P($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&B_factor($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);
&PSSM1($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1); 
&conserve_score($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p,$line1);

&feature_combine($m_in,$a[1],$a[2],$a[4],$line1);  #注意修改
#&predict($m_in,$a[1],$a[2],$a[4],$line1);#注意修改
             
   }
}
}
sub funall_cal(){
	use IO::File;  #很重要
	my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
	my $in1=new IO::File("<$dir/$pdb\.pdb") or die "$!";   #pdb  position
	my $out1=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$pdb\.$chain\.$atom_pos\.cluster\.$p") or die "$!";  #output residues in the centered cluster file
       my $out2=new IO::File(">>$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$metal\.$pdb\.$chain\.$atom_pos\.cluster\.$p") or die "$!"; # output the name of all centered residues cluster #注意修改
     print $out2 "$pdb\.$chain\.$atom_pos\.cluster\.$p     $metal\n";
      while(my $line1=<$in1>){
          chomp $line1;
          if(!($line1 ~~ /^ATOM/)){
         		next;
         	}
         	my $c_type=substr($line1,17,3);
         	my $cc=substr($line1,16,1);
         	my $c_chain=substr($line1,21,1);
         	my $ca=substr($line1,13,2);
         	my $c_atom_pos=substr($line1,22,4);
         	$c_atom_pos=~s/^\s+|\s+$//;
         	
         	if(!($ca eq "CA")){
         		next;
         	}
         		my $c_x=substr($line1,30,8);
         		   $c_x=~s/^\s+|\s+$//;
         		my $c_y=substr($line1,38,8);
         		   $c_y=~s/^\s+|\s+$//;
         		my $c_z=substr($line1,46,8);
         		   $c_z=~s/^\s+|\s+$//;
         		my $ppp=sqrt(($x-$c_x)*($x-$c_x)+($y-$c_y)*($y-$c_y)+($z-$c_z)*($z-$c_z));
         		print $out1 "$metal\_$pdb\_$chain\_$type\_$atom_pos\_$x\_$y\_$z\_$seq_pos            $metal\_$pdb\_$c_chain\_$c_type\_$c_atom_pos\_$c_x\_$c_y\_$c_z\_$seq_pos            $ppp\n";

      }
}

print "$m_in\n";



sub andrew_10_cluster(){
use IO::File;
#use strict;
#&RF_sort_hash_select();
	 	my $metal=shift;  #注意修改
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
my $line1=shift;

&funall1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p);   #注意修改
&andrew_feature_extraction($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p);  #注意修改





sub funall1(){
	use IO::File;
	 	my $metal=shift;  #注意修改
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	for my $p("all"){
   
	my $in1=new IO::File("<$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$metal\.$pdb\.$chain\.$atom_pos\.cluster\.$p") or die "$!";  # input the name of all residue centered cluster  #注意修改
	#my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\my_queshi_zincfinder.txt") or die;
	#my $out1=new IO::File(">C:\\Users\\zc870328\\Desktop\\my_compare_zincfinder.txt") or die;
	#my $out2=new IO::File(">C:\\Users\\zc870328\\Desktop\\apo_zinc_605") or die;
   while(my $line1=<$in1>){
          chomp $line1;
          my @a=split/\s+/,$line1;
             &RF_sort_hash_select($metal,$a[0],$p,$pdb,$chain,$atom_pos);
             &cluster_select($metal,$a[0],$p,$pdb,$chain,$atom_pos); #注意修改
   
}
}
}



sub RF_sort_hash_select(){
	use IO::File;
    	my $metal=shift;
	    my $file=shift;
	    my $p=shift;
	    my $pdb=shift;
	my $chain=shift;
	
	my $atom_pos=shift;
    	my $in=new IO::File("<$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$file") or die "$!";   #  input residues in the centered cluster file
        my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/sort\_$file") or die "$!";   # output  sort residues by distance
       	my @arr;
       	my %hash;
       	while(<$in>){
       		  chomp;
       		  s/^\s+//;
       		  my @list=split/\s+/,$_;
       	 	  $hash{$_}=$list[2];
       	}
       @arr=sort {$hash{$a} <=> $hash{$b}} (keys (%hash));	  #paixu   $a  $b  duihuanweizhi    shunxubian
       foreach my $key (@arr) {
       		print $out "$key\n";
       }
       #my @list=split/\s+/,$arr[0];    #???
       #my @list1=split/-/,$list[0];    #???
       #print $arr[0];
       #print $list[0];
       #return $list[0];
    }



sub cluster_select(){
	use IO::File;
    	my $metal=shift;  #注意修改
    	print "$metal\n";
	    my $file=shift;
	    my $p=shift;
	    my $pdb=shift;
	my $chain=shift;
	
	my $atom_pos=shift;
    	my $out=new IO::File(">>$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$metal\_$pdb\_$chain\_$atom_pos\_cluster_10_last_$p") or die "$!";  #注意修改  #output 10 residues in the cluster 
        my $in=new IO::File("<$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/sort\_$file") or die "$!";  # input  sort residues by distance
       	 $.=0;
       	while(<$in>){
       		  chomp;
       		  print "$_\n";
       		
       		  if ($. <= 10){
       		  	my @list=split/\s+/,$_;
       		  	print $out "$list[1]                  ";
       		  }
       		  elsif($. > 10){
       		  	next;
       		  }
       		 
    }
    print $out "\n";
     
}

sub andrew_feature_extraction(){
	use IO::File;
		my $metal=shift;  #注意修改
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	
for my $p("all"){
  print  "$dir/$metal\_$pdb\_$chain\_$atom_pos\_cluster_10_last_$p\n";
	my $in1=new IO::File("<$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$metal\_$pdb\_$chain\_$atom_pos\_cluster_10_last_$p") or die "$!";#input 10 residues in the cluster 
	 while(my $line1=<$in1>){
          chomp $line1;
          
          my @a=split/\s+/,$line1;
          my @a0=split/\_/,$a[0];
          my @a1=split/\_/,$a[1];
          my @a2=split/\_/,$a[2];
          my @a3=split/\_/,$a[3];
          my @a4=split/\_/,$a[4];
          my @a5=split/\_/,$a[5];
          my @a6=split/\_/,$a[6];
          my @a7=split/\_/,$a[7];
          my @a8=split/\_/,$a[8];
          my @a9=split/\_/,$a[9];
          
          
           &andrew_pair_number($metal,$a[0],$a0[3],$a1[3],$a2[3],$a3[3],$a4[3],$a5[3],$a6[3],$a7[3],$a8[3],$a9[3],$p,$a0[1],$a0[2],$a0[4]); #注意修改
            
             
            
             &C_H_E_D_CH_CHED_number_and_percentage($metal,$a[0],$a0[3],$a1[3],$a2[3],$a3[3],$a4[3],$a5[3],$a6[3],$a7[3],$a8[3],$a9[3],$p,$a0[1],$a0[2],$a0[4]);  #注意修改
             &C_H_E_D_type($metal,$a[0],$a0[3],$a1[3],$a2[3],$a3[3],$a4[3],$a5[3],$a6[3],$a7[3],$a8[3],$a9[3],$p,$a0[1],$a0[2],$a0[4]);  #注意修改
            
             
             
             
             
	 }            
             
   }
}


sub andrew_pair_number(){
	use IO::File;
	my @b;
	my %hash;
	my $metal=shift;
	 my $file=shift;  
         $b[0]=shift;  
	     $b[1]=shift;
	    $b[2]=shift;
	      $b[3]=shift;
	    $b[4]=shift;
	     $b[5]=shift;
	     $b[6]=shift;
	     $b[7]=shift;
	     $b[8]=shift;
	    $b[9]=shift;
	      my $p=shift;
	     $pdb=shift;    #注意修改
	     $chain=shift;
	    $atom_pos=shift;
	    
	    
	     my $out=new IO::File(">>$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/andrew_pair_number\_$p") or die "$!";   #result file1   #注意修改
	     #print "$file\n";
	     $file=~s/\_/ /g;
	      print "$file\n";
	     print $out "$file     ";
	     for(my $r=0;$r<=9;$r++){
	     	
	     	$hash{$b[$r]}="$b[$r]   ";
	        }
	     
	   #  	foreach my $x (values %hash){   not output the type of aa  in the cluster
    # print $out "$x";
	#}
	  $a=keys%hash;   #jisuan  key number  very important
	  my $b=$a*($a-1)/2;
	     print $out "   $a         $b\n";
	  # print $out2" $metal @b    $b[0]    $b[1]   $b[2]  $b[9]\n";
	  
    }



sub C_H_E_D_CH_CHED_number_and_percentage(){
	use IO::File;
	my @b;
	my %hash;
	my $metal=shift;
	 my $file=shift;  
         $b[0]=shift;  
	     $b[1]=shift;
	    $b[2]=shift;
	      $b[3]=shift;
	    $b[4]=shift;
	     $b[5]=shift;
	     $b[6]=shift;
	     $b[7]=shift;
	     $b[8]=shift;
	    $b[9]=shift;
	     my $p=shift;
	     $pdb=shift;    #注意修改
	     $chain=shift;
	    $atom_pos=shift;
	     
	     
	     my $out=new IO::File(">>$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/andrew_ched_number\_$p") or die "$!";   #result file2   #注意修改
	      $c=0;
        $h=0;
       $d=0;
        $e=0;
        $file=~s/\_/ /g;
	      print "$file\n";
	     print $out "$file     ";
	     for(my $r=0;$r<=9;$r++){
	     	
           		if($b[$r] eq "CYS"){
           			$c+=1;
           		}
                elsif($b[$r] eq "HIS"){
           			$h+=1;
                }
                elsif($b[$r] eq "ASP"){
           			$e+=1;
                }
                elsif($b[$r] eq "GLU"){
           			$d+=1;
                }
        }
        my $sum_ch = $c+$h;
       my $sum_ched = $c+$h+$d+$e;
        
        print $out "   number(C   H   E   D   CH   CHED)     $c    $h    $e    $d    $sum_ch    $sum_ched\n"; # print $out "@b   number(C   H   E   D   CH   CHED)     $c    $h    $e    $d    $sum_ch    $sum_ched\n";
        
    }



sub C_H_E_D_type(){
	use IO::File;
	my @b;
	my %hash;
	my $metal=shift;
	 my $file=shift;  
         $b[0]=shift;  
	     $b[1]=shift;
	    $b[2]=shift;
	      $b[3]=shift;
	    $b[4]=shift;
	     $b[5]=shift;
	     $b[6]=shift;
	     $b[7]=shift;
	     $b[8]=shift;
	    $b[9]=shift;
	     my $p=shift;
	     $pdb=shift;    #注意修改
	     $chain=shift;
	    $atom_pos=shift;
	    
	    
	     my $out=new IO::File(">>$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/andrew_residue_score\_$p") or die "$!";   #result file3  #注意修改
	      $file=~s/\_/ /g;
	      print "$file\n";
	     print $out "$file        CHED_esle_10_10_5_5_1   ";#print $out "$file   @b       CHED_esle_10_10_5_5_1   ";
	     
	     	   $c=0;
           		   		for(my $r=0;$r<=9;$r++){
	     	
           		if($b[$r] eq "CYS"){
           			$c=$c+10;
           		}
                elsif($b[$r] eq "HIS"){
           			$c=$c+10;
                }
                elsif($b[$r] eq "ASP"){
           			$c=$c+5;
                }
                elsif($b[$r] eq "GLU"){
           			$c=$c+5;
                }
                else{
           			$c=$c+1;
                }
        }
      
      
        
        print $out "  $c                   \n";
        
    }









sub funallhy(){
	use IO::File;
	 for my $p("all"){    	#zhihou   zai  add "ne"  
    
	 my $line1=shift;   #sample#input samples  list
	   
          chomp $line1;
          my @a=split/\s+/,$line1;
             &funall_calhy($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$p);
             &funall_calhy1($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$p);
             &funallhy1($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$p,$line1);   #注意修改
   
}
}

sub funall_calhy(){
	use IO::File;
	my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $p=shift;
	print "$pdb $chain\n";
	my $in1=new IO::File("<$dir/$pdb\_$chain\.fasta.txt") or die;  #fasta   position
	my $out1=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$pdb\_$chain\.sequence") or die;  # output sequence in one line
      #my $out2=new IO::File(">>C:\\Users\\zc870328\\Desktop\\Metal_binding\\metal_dataset\\dataset_last\\dataset\\metal\_cluster\\$metal\.cluster\.$p") or die;
      #print $out2 "$pdb\.$chain\.$atom_pos\.cluster\.$p\n";
      my $line1=<$in1>;
      while(my $line1=<$in1>){
          chomp $line1;
         print $out1 "$line1"; 
}
print $out1 "\n";
}



sub funall_calhy1(){
	use IO::File;
		my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $p=shift;
	my $in1=new IO::File("<$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$pdb\_$chain\.sequence") or die;  #input sequence in one line
	#my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\my_queshi_zincfinder.txt") or die;
	my $out1=new IO::File(">>$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$metal\_$pdb\_$chain\_$atom_pos\_hypergeom\_$p") or die;   #initial  file
	#my $out2=new IO::File(">C:\\Users\\zc870328\\Desktop\\apo_zinc_605") or die;
 my $line1=<$in1>;
          chomp $line1;
         $line1=~s/^\s+|\s+$//;
           my $length=length($line1);
           my @a=();
           my $c=@a=$line1=~m/C/g;
           my $h=@a=$line1=~m/H/g;
           my $e=@a=$line1=~m/E/g;
           my $d=@a=$line1=~m/D/g;
           my $sum=$c+$h+$e+$d;
           my $C=$c/$sum;
           my $H=$h/$sum;
           my $E=$e/$sum;
           my $D=$d/$sum;
           my $C_P=$c/$length;
           my $H_P=$h/$length;
           my $E_P=$e/$length;
           my $D_P=$d/$length;
           
           my $type_num=0;
             if($type eq "CYS"){
           			$type_num= $c;
           		}
                elsif($type eq "HIS"){
           			$type_num= $h;
                }
                elsif($type eq "ASP"){
           			$type_num= $e;
                }
                elsif($type eq "GLU"){
           			$type_num= $d;
                }
                
             my $type_not=$length-$type_num;
             print $out1 "$metal $pdb\_$chain\_$type\_$atom_pos\_$x\_$y\_$z   chain_l hy3   C_sum_chain H_sum_chain E_sum_chain D_sum_chain   C_p_chain H_p_chain E_p_chain D_p_chain   $length    $type_num    $type_not   10  $c  $h  $e  $d  $C_P  $H_P  $E_P  $D_P \n"  
                
}

	sub funallhy1(){
		use IO::File;
		my $metal=shift;   #注意修改
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $p=shift;
	my $line1=shift;
	
	 for my $p("all"){    	#zhihou   zai  add "ne"  
    
	   	   # my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
	   my $in2=new IO::File("<$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$metal\_$pdb\_$chain\_$atom_pos\_hypergeom\_$p") or die; #initial file
	   my $in3=new IO::File("<$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/andrew_ched_number\_$p") or die;   #input andrew_ched_number_all file
	   my $out1=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/hypergeom\_4\_$p") or die;  #result file
	   
          chomp $line1;
          my @a=split/\s+/,$line1;
          my $type=$a[3];
          
          my $type_10=0;
          
          my $line2=<$in2>;
          chomp $line2;
          my @b=split/\s+/,$line2;
          
          
          my $line3=<$in3>;
          chomp $line3;
          my @c=split/\s+/,$line3;
          
          
          if($type eq "CYS"){
           			$type_10= $c[-6]-1;
           		}
                elsif($type eq "HIS"){
           			$type_10= $c[-5]-1;
                }
                elsif($type eq "ASP"){
           			$type_10= $c[-4]-1;
                }
                elsif($type eq "GLU"){
           			$type_10= $c[-3]-1;
                }
                
      print $out1 "$line1     $type_10   $b[-11] $b[-10] $b[-9] \n";       
   
}
}
}










































sub residue_type(){
use IO::File;
	my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
my $line1=shift;
for my $m("all"){
 #my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out1=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/residue_type\_$m") or die;  #result  file
    

		chomp $line1;
		$x=0;
		$y=0;
		 @c=split/\s+/,$line1;
	    if($c[3] eq "CYS"){
           			$x=10;
           			$y=1000;
           		}
                elsif($c[3] eq "HIS"){
           			$x=10;
           			$y=100;
                }
                elsif($c[3] eq "ASP"){
           			$x=5;
           			$y=10;
                }
                elsif($c[3] eq "GLU"){
           			$x=5;
           			$y=1;
                }
	    	print $out1 "$c[0]                $c[1]    $c[2]   $c[3]   $c[4]   $c[5]     $c[6]  $c[7]  $c[8]                         CHED_10_10_5_5        CHED_1000_100_10_1                      $x   $y\n";
	    
	 }
}






































sub net(){
 # PSSM
   # rsa ???
     
use warnings;


use IO::File; 
#use strict; 
  my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift; 
	my $line1=shift;
    &PSSM($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
     
    sub PSSM(){ 
    	 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift; 
  my $line1=shift;
    	my $in3=new IO::File("<$dir/net_tital") or die;  #list of network feature
    	  while(<$in3>){
       	  	chomp;
       	  	my @t=split/\s+/;
       	  
    for my $p("all"){
	for(my $q=1;$q<=12;$q++){
       	  #  my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
          my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/net\_$t[$q]\_$p") or die;  #result files
       	 
       	  	chomp $line1;
       	  	my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position   ###   $m\_net/net_param\_{$pdb}\.pdb\_$chain\_6\.5_1\.txt
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/net_param\_$pdb\.pdb\_$chain\_6\.5_1\.txt")){
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/net_param\_$pdb\.pdb\_$chain\_6\.5_1\.txt") or die "$!";  #input network files
       	 
                  &PSSM_2($in2,$Aps,$out,$line1,$chain,$pos,$q);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
         }
       	  
         #$in1->close;
         $out->flush();
         $out->close;
       	  
       }   
    }
    }
  }
    sub PSSM_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
             my $q=shift;
             #my $p=0;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	chomp $line2;
           	my @m=split/\s+/,$line2;
           	my @n=split/\-/,$m[0];
              my $mn=$n[1];
             
              #my $ppp=substr($line2,22,4);
              #$mn=~s/^\s+//;
             
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=$m[$q];  # the value you want
                        $y=~s/^\s+//;
                        print "$y net\n";
                        my $ppp= $mn;# pos  or aps
                         $ppp=~s/^0+//;
                    
                            $hash{$ppp}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
     
     
  }   
     	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub nac_total_side_rel(){	
 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
  my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
    &nac_total_side_rel1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
 
    
    sub nac_total_side_rel1(){ 
    	 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
   my $line1=shift;
    for my $p("all"){
	
       	     #my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_total_side_rel\_$p") or die; #result file
       	  
       	  	chomp $line1;
       	  	my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";  #input .rsa file
          
                  &nac_total_side_rel_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
        # $in1->close;
        $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_total_side_rel_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,35,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_total_side_rel\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
}     
     
     
      	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub nac_total_side_abs(){	
	 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
    &nac_total_side_abs1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub nac_total_side_abs1(){ 
    	my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
   my $line1=shift;
    for my $p("all"){
	
       	    # my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_total_side_abs\_$p") or die;  #result file
       	  
       	  	chomp $line1;
       	  	my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";  #input .rsa file
          
                  &nac_total_side_abs_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
        # $in1->close;
         $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_total_side_abs_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,29,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_total_side_abs\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
      
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub nac_non_polar_rel(){	
	 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
    &nac_non_polar_rel1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub nac_non_polar_rel1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift; 
    for my $p("all"){
	
       	    # my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_non_polar_rel\_$p") or die;   #result file
       	  
       	  	chomp $line1;
       	  	my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";#input .rsa file
          
                  &nac_non_polar_rel_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_non_polar_rel_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,61,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_non_polar_rel\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
     
}     
     
      
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub nac_non_polar_abs(){	
	 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
    &nac_non_polar_abs1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub nac_non_polar_abs1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift; 
    for my $p("all"){
	
       	   # my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_non_polar_abs\_$p") or die;  #result file
       	  
       	  	chomp $line1;
       	  	my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";  #input .rsa file
          
                  &nac_non_polar_abs_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
        # $in1->close;
         $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_non_polar_abs_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,55,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_non_polar_abs\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
      
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub nac_main_chain_rel(){	
	 # PSSM
   # rsa ???
     
use warnings;

  
use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
    &nac_main_chain_rel1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub nac_main_chain_rel1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
    for my $p("all"){
	
       	    #  my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_main_chain_rel\_$p") or die;
       	  chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";
          
                  &nac_main_chain_rel_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_main_chain_rel_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,48,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_main_chain_rel\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
      
	
sub  nac_main_chain_abs(){	
	
	 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    &nac_main_chain_abs1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub nac_main_chain_abs1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    for my $p("all"){
	
       	     # my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_main_chain_abs\_$p") or die; #result file 
       	 	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";  #input .rsa file
          
                  &nac_main_chain_abs_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 
         }
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_main_chain_abs_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,42,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_main_chain_abs\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
      
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub nac_all_polar_rel(){	
	
	 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    &nac_all_polar_rel1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub nac_all_polar_rel1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    for my $p("all"){
	
       	 #  my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_all_polar_rel\_$p") or die;  #result file
       	   chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";  #input .rsa file
          
                  &nac_all_polar_rel_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_all_polar_rel_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,74,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_all_polar_rel\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
      
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub nac_all_polar_abs(){	
 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict; 
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift; 
		my $line1=shift; 
    &nac_all_polar_abs1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub nac_all_polar_abs1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    for my $p("all"){
	
 #my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_all_polar_abs\_$p") or die;  #result file
       	   chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";  #input .rsa file
          
                  &nac_all_polar_abs_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_all_polar_abs_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,68,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_all_polar_abs\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
      	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub nac_all_atom_rel(){	
 # PSSM
   # rsa ???
     
use warnings;

  

use IO::File; 
use strict; 
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift; 
		my $line1=shift;
    &nac_all_atom_rel1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub nac_all_atom_rel1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    for my $p("all"){
	 my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
	  my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_all_atom_rel\_$p") or die;  #result file
       	   chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";  #input .rsa file
          
                  &nac_all_atom_rel_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_all_atom_rel_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,22,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_all_atom_rel\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
      	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub nac_all_atom_abs(){	
	
 # PSSM
   # rsa ???
     
use warnings;

  
use IO::File; 
use strict; 
my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift; 
		my $line1=shift;
    &nac_all_atom_abs1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub nac_all_atom_abs1(){ 
   my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    for my $p("all"){
	
       	 #   my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
       	     my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/nac_all_atom_abs\_$p") or die;  #result file
       	 	
	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
               if(!(-e "$dir/$pdb\.rsa")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.rsa") or die "$!";  #input .rsa file
          
                  &nac_all_atom_abs_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
     
  
    sub nac_all_atom_abs_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,8,1);
             # my $ca=substr($line2,13,2);
              if ($. <= 4){
              	next;
              }
              my $ca=substr($line2,9,4);
              $ca=~s/^\s+//;
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,16,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y nac_all_atom_abs\n";
                        my $p= $ca ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
}     
     
     
      	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub ex(){	
	 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict; 
my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift; 
		my $line1=shift;
    &ex1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub ex1(){ 
   my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    for my $p("all"){
	for my $q("CN","HSEAD","HSEAU","HSEBD","HSEBU","RD","RDa"){
       	  #	my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/ex\_$q\_$p") or die;   #result files
       	  	
	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position   ###   $m\_net/net_param\_{$pdb}\.pdb\_$chain\_6\.5_1\.txt
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/ex\_$pdb\_$q")){
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/ex\_$pdb\_$q") or die "$!"; #input the result of exposure files eg, ex_1A0B_RD
       	 
                  &ex_2($in2,$Aps,$out,$line1,$chain,$pos,$q);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
         }
       	  
         #$in1->close;
         $out->flush();
         $out->close;
       	  
       }   
    }
    }
  
    sub ex_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
             my $q=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,21,1);
              my $ca=substr($line2,13,2);
              
              my $ppp=substr($line2,22,4);
              $ppp=~s/^\s+//;
              if (!(($c eq $chain)&&($ca eq "CA"))){
              	next;
             }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=$list[-2];  # the value you want
                        $y=~s/^\s+//;
                        print "$y exposure    $pos   $q\n";
                        my $p= $ppp ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
     
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
sub DSSP_tco(){
		
 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    &DSSP_tco1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub DSSP_tco1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    for my $p("all"){
	
       	         #	  	my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/DSSP_tco\_$p") or die;    #result file
       	  	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\.dssp")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.dssp") or die "$!";   #input .dssp
          
                  &DSSP_tco_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
    
  
    sub DSSP_tco_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,11,1);
              if ($. <= 28){
              	next;
              }
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,85,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y DSSP_tco\n";
                        my $p= $list[2] ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
}



#############################################################################3









sub DSSP_ss(){

 # PSSM
   # rsa ???
     
use warnings;

  
use IO::File; 
use strict; 
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift; 
    &DSSP_ss1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub DSSP_ss1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
    for my $p("all"){
	
 	#my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/DSSP_ss\_$p") or die;   #result file
       	  	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\.dssp")){      ###dssp file   
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.dssp") or die "$!";   #input .dssp
          
                  &DSSP_ss_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
    
  
    sub DSSP_ss_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
              my @c=split/\s+/,$line;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,11,1);
              if ($. <= 28){
              	next;
              }
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,16,1);  # the value you want
                        $y=~s/^\s+//;
                        print "$y DSSP_ss\n";
                        my $p= $list[2] ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0; 
				}                      
				elsif($hash{$i} eq "H"){
					$hash{$i}=1000;	
				}
				elsif($hash{$i} eq "G"){
					$hash{$i}=1000;	
				}
				elsif($hash{$i} eq "I"){
					$hash{$i}=1000;	
				}
				
				elsif($hash{$i} eq "E"){
					$hash{$i}=100;	
				}
				elsif($hash{$i} eq "B"){
					$hash{$i}=10;	
				}
				elsif($hash{$i} eq "T"){
					$hash{$i}=10;	
				}
				elsif($hash{$i} eq "S"){
					$hash{$i}=10;	
				}
				elsif($hash{$i} eq "C"){
					$hash{$i}=10;	
				}
				else{
					$hash{$i}=1;	
				}
				
				
				
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
     
 }    
     
    





















sub DSSP_psi(){

 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
    &DSSP_psi1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub DSSP_psi1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $line1=shift;
    for my $p("all"){
	
 	#my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/DSSP_psi\_$p") or die;   #result file 
       	 	
	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\.dssp")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.dssp") or die "$!";   #input .dssp
          
                  &DSSP_psi_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
    
  
    sub DSSP_psi_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,11,1);
              if ($. <= 28){
              	next;
              }
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,109,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y DSSP_psi\n";
                        my $p= $list[2] ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
}     
     
     
    



















sub DSSP_phi(){
 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    &DSSP_phi1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub DSSP_phi1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    for my $p("all"){
	
       	   #	my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/DSSP_phi\_$p") or die;  #result file
       	 	
	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\.dssp")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.dssp") or die "$!";  #input .dssp
          
                  &DSSP_phi1_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
    
  
    sub DSSP_phi1_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,11,1);
              if ($. <= 28){
              	next;
              }
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,103,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y DSSP_phi1\n";
                        my $p= $list[2] ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
    


















sub DSSP_kappa(){
 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    &DSSP_kappa1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub DSSP_kappa1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    for my $p("all"){
	
       	  
       	 #  	my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/DSSP_kappa\_$p") or die;  #result file
       	  	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\.dssp")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.dssp") or die "$!";  #input .dssp
          
                  &DSSP_kappa_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
    
  
    sub DSSP_kappa_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,11,1);
              if ($. <= 28){
              	next;
              }
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,92,5);  # the value you want
                        $y=~s/^\s+//;
                        print "$y DSSP_kappa\n";
                        my $p= $list[2] ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
    





















sub DSSP_alpha(){
 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict; 
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    &DSSP_alpha1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub DSSP_alpha1(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    for my $p("all"){
	
       	  	#my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/DSSP_alpha\_$p") or die;  #result file
       	 	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\.dssp")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.dssp") or die "$!";   #input .dssp
          
                  &DSSP_alpha_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 
         }
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
    
  
    sub DSSP_alpha_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,11,1);
              if ($. <= 28){
              	next;
              }
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,97,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y DSSP_alpha\n";
                        my $p= $list[2] ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
    


































































sub DSSP_acc(){
 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict; 
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    &DSSP_acc1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub DSSP_acc1(){ 
   my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    for my $p("all"){
	
       	   
       	#  	my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/DSSP_acc\_$p") or die;  #result file
       		 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\.dssp")){      ###dssp file
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.dssp") or die "$!";   #input .dssp
          
                  &DSSP_acc_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
       	 }
         
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
    
  
    sub DSSP_acc_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,11,1);
              if ($. <= 28){
              	next;
              }
              if ($c ne $chain){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,34,4);  # the value you want
                        $y=~s/^\s+//;
                        print "$y DSSP_acc\n";
                        my $p= $list[2] ;# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
 }    
     
     
    














sub diso(){
 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;  
my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    &diso1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub diso1(){
    	my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift; 
    	my $in3=new IO::File("<$dir/diso_tital") or die;   # list of  these three features
    	  while(<$in3>){
       	  	chomp;
       	  	my @t=split/\s+/;
       	  
    for my $p("all"){
	for(my $q=1;$q<=3;$q++){
       	    # my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$t[$q]\_$p") or die;   #result files  (3)
       	  	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position   ###   $m\_net/net_param\_{$pdb}\.pdb\_$chain\_6\.5_1\.txt
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\_$chain\.fasta\.diso")){
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\_$chain\.fasta\.diso") or die "$!";   # input .diso   file
       	 
                  &diso_2($in2,$Aps,$out,$line1,$chain,$pos,$q);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
         }
       	  
        # $in1->close;
         $out->flush();
         $out->close;
       	  
       }   
    }
    }
  }
    sub diso_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
             my $q=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$pos-$length;
           my $end=$pos+$length;
           my %hash=();
           $.=0;
           
           while(defined(my $line2=<$in2>)){
           	chomp $line2;
           	if($. <= 5){
           	next;
          }
           	my @m=split/\s+/,$line2;
           #	my @n=split/\-/,$m[0];
              #my $mn=$n[1];
             
              #my $ppp=substr($line2,22,4);
              #$mn=~s/^\s+//;
             
              #$line2=~s/^\s+//;
              	  
              	  	 # my @list=split/\s+/,$line2;  #chain id
                        my $y=$m[$q+2];  # the value you want
                        $y=~s/^\s+//;
                        print "$y diso\n";
                        my $p= $m[1];# pos  or aps
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if($hash{$i} eq "."){
					$hash{$i}=1;                       
					
				}
				if($hash{$i} eq "*"){
					$hash{$i}=10;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
     
     
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

     
    
    
    sub PSSM1(){
    	 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift; 
  	my $line1=shift; 
    for my $p("all"){
	
       	 # my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/PSSM\_$p") or die;  #result file
       	 	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\_$chain.fasta\.pssm")){
       	  	print $out "$line1                    0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                      \n";
       	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\_$chain.fasta\.pssm") or die "$!";  #input .pssm file
          
                  &PSSM1_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
         }
       
         #$in1->close;
         $out->flush();
         $out->close;
       }   
    }
    
  
    sub PSSM1_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$pos-$length;
           my $end=$pos+$length;
           my %hash=();
           while(defined(my $line2=<$in2>)){
              chomp $line2;
              $line2=~s/^\s+//;
              	  if($line2~~/^\d/){
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y="$list[2] $list[3] $list[4] $list[5] $list[6] $list[7] $list[8] $list[9] $list[10] $list[11] $list[12] $list[13] $list[14] $list[15] $list[16] $list[17] $list[18] $list[19] $list[20] $list[21]";  # the value you want
                        my $p= $list[0] ;# pos
                        $p=~s/^0+//;
                    
                            $hash{$p}=$y;
                        }
                  }
         
          
           print $out "$line                    ";
		   for(my $i=$pos-$length;$i<=$pos+$length;$i++){
				#print " $i ";
				
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0                       ";
				
				}
			}
			
 	}
     
     







    
   # &conserve_score_cal(); 
sub conserve_score(){
	 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;  
	for my $p("all"){

       	  #   my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out1=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/conserve_score\_$p") or die;   #result file
       	 	
	 chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\_$chain.fasta\.pssm")){
       	  	print $out1 "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       		 	  print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\_$chain.fasta\.pssm") or die "$!";   #pssm file  position
          
             	my %exist=();
        	
        	my %score=();
        	my $window_size= 11;
             # print "$s\n";
            my $length=($window_size-1)/2;
            print $out1 "$line1                     ";
        	for(my $k=$pos-$length;$k<=$pos+$length;$k++){
        		
        	while(defined(my $l2=<$in2>)){
        		 $l2=~s/^\s+//;
        		my @list2=split/\s+/,$l2;
        		next if (not defined $list2[0] or $list2[0]~~/\D/);
        		my $x = $list2[22]+$list2[23]+$list2[24]+$list2[25]+$list2[26]+$list2[27]+$list2[28]+$list2[29]+$list2[30]+$list2[31]+$list2[32]+$list2[33]+$list2[34]+$list2[35]+$list2[36]+$list2[37]+$list2[38]+$list2[39]+$list2[40]+$list2[41];
        		#print "$x\n";
        		if($list2[0] == $k){
        			$exist{$k}=1;
        			$score{$k}=conserve_score_cal($l2,$x);
        		}
        		
        		
        		}
        	seek $in2,0,0;
        #	print $out "$_                    "; 
        	
        	
        	if($exist{$k}==1){
        		print $out1 " $score{$k}    ";
        	}
        	else{
        		print $out1 " 0    ";
        	
       	  }
       }
       print $out1 " \n";
     }
       	  
	}

}

sub conserve_score_cal(){
       	my $line=shift;
       	my $x=shift;
       	$line=~s/^\s+//;
       	my @list=split/\s+/,$line;
       	my $i;
       	my $sum=0;
       	for($i=22;$i<=41;$i++){
       		# print "$list[$i]\n";
       		if($list[$i]==0){next;}
       		else{
       			$sum=$sum+($list[$i]/$x)*log($list[$i]/$x)/log(2);
       		}
       	}
       #	print -$sum;
       	return (-$sum);
       }
       
 }           
        






















sub ched_P(){
use IO::File;
#use strict;
#&RF_sort_hash_select();
   my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
&ched_P1($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);
#&funall1();
#&andrew_feature_extraction();

sub ched_P1(){
	     my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift; 	#zhihou   zai  add "ne"  
		my $line1=shift;
    for my $p("all"){
	#my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
	   
          chomp $line1;
          my @a=split/\s+/,$line1;
             &funall_calched_P($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8]);
             &funall_cal1ched_P($a[0],$a[1],$a[2],$a[3],$a[4],$a[5],$a[6],$a[7],$a[8],$p);
   
}
}

sub funall_calched_P(){
	my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $p=shift;
	print "$pdb $chain\n";
	my $in1=new IO::File("<$dir/$pdb\_$chain\.fasta.txt") or die; #fasta  position
	my $out1=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$pdb\_$chain\.sequence") or die;  #output sequence in one line
      #my $out2=new IO::File(">>C:\\Users\\zc870328\\Desktop\\Metal_binding\\metal_dataset\\dataset_last\\dataset\\metal\_cluster\\$metal\.cluster\.$p") or die;
      #print $out2 "$pdb\.$chain\.$atom_pos\.cluster\.$p\n";
      my $line1=<$in1>;
      while(my $line1=<$in1>){
          chomp $line1;
         print $out1 "$line1"; 
}
print $out1 "\n";
}



sub funall_cal1ched_P(){
		my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
	my $in1=new IO::File("<$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/$pdb\_$chain\.sequence") or die;#input sequence in one line
	#my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\my_queshi_zincfinder.txt") or die;
	my $out1=new IO::File(">>$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/CHED\_P\_$p") or die;   #result file
	#my $out2=new IO::File(">C:\\Users\\zc870328\\Desktop\\apo_zinc_605") or die;
 my $line1=<$in1>;
          chomp $line1;
         $line1=~s/^\s+|\s+$//;
           my $length=length($line1);
           my @a=();
           my $c=@a=$line1=~m/C/g;
           my $h=@a=$line1=~m/H/g;
           my $e=@a=$line1=~m/E/g;
           my $d=@a=$line1=~m/D/g;
           my $sum=$c+$h+$e+$d;
           my $C=$c/$sum;
           my $H=$h/$sum;
           my $E=$e/$sum;
           my $D=$d/$sum;
           my $C_P=$c/$length;
           my $H_P=$h/$length;
           my $E_P=$e/$length;
           my $D_P=$d/$length;
           
           my $type_num=0;
             if($type eq "CYS"){
           			$type_num= $c;
           		}
                elsif($type eq "HIS"){
           			$type_num= $h;
                }
                elsif($type eq "ASP"){
           			$type_num= $e;
                }
                elsif($type eq "GLU"){
           			$type_num= $d;
                }
                
             my $type_not=$length-$type_num;
             print $out1 "$metal    $pdb   $chain   $type   $atom_pos     $x  $y  $z   $seq_pos                  chain_l   C_sum_chain H_sum_chain E_sum_chain D_sum_chain   C_p_chain H_p_chain E_p_chain D_p_chain   $length      $c  $h  $e  $d  $C_P  $H_P  $E_P  $D_P\n"  
                
}

}	  



















sub B_factor(){
	 # PSSM
   # rsa ???
     
use warnings;
  

use IO::File; 
use strict;
 my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;  
    &B($metal,$pdb,$chain,$type,$atom_pos,$x,$y,$z,$seq_pos,$p,$line1);  
    
    
    sub B(){ 
    my $metal=shift;
	my $pdb=shift;
	my $chain=shift;
	my $type=shift;
	my $atom_pos=shift;
	my $x=shift;
	my $y=shift;
	my $z=shift;
	my $seq_pos=shift;
	my $p=shift;
		my $line1=shift;
    for my $p("all"){
	
       	 #  my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
 my $out=new IO::File(">$dir/result\_$metal\_$pdb\_$chain\_$atom_pos/B_factor\_$p") or die;  #result file    #result file
       	   chomp $line1;
          my @all=split/\s+/,$line1;
            my $aa = $all[3];
		 	
		 	my $Aps = $all[4];
		 	                                           
		 	my $pos = $all[-1];
         	my $m = $all[0];                                    
        
         	my $pdb = $all[1];
         	my $chain = $all[2];
       	  #	my @list=split/\s+/;  #pdb is pdb id  pos is position
       	  print "$pdb $chain\n";
       	  if(!(-e "$dir/$pdb\.pdb")){
       	  	print $out "$line1                    0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      0                      \n";
       	   print "error  \n";
       	  }
       	 else{
               my $in2=new IO::File("<$dir/$pdb\.pdb") or die "$!";   #pdb  position
          
                  &B_2($in2,$Aps,$out,$line1,$chain,$pos);
                   print $out "                       \n";                              #??????  ??????????з?
                   
                #   print "$all[2]  $all[1]\n";
             	   $in2->close;
         }
       
        # $in1->close;
         $out->flush();
         $out->close;
       }   
    }
    
  
    sub B_2(){
    		 
             my $in2=shift;      
             # my $in2=new IO::File("<C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\1AQ8.rsa") ;
             my $Aps=shift;
             my $out=shift;
         # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\feature values\\rsa\\111.rsa");
             my $line=shift;
             my $chain=shift;
             my $pos=shift;
            # my $out=new IO::File(">C:\\Users\\zc870328\\Desktop\\zinc-binding\\Supplementary_file\\SASA_side_RE$s.txt") or die "$!";
             #  my $pos=11;
             my $window_size= 11;
              #print "$s\n";
             my $length=($window_size-1)/2;
           my $head=$Aps-$length;
           my $end=$Aps+$length;
           my %hash=();
           $.=0;
           while(defined(my $line2=<$in2>)){
           	
              chomp $line2;
              my $c=substr($line2,21,1);
              my $ca=substr($line2,13,2);
              if (!($line2 ~~ /^ATOM/)){
              	next;
              }
              if (!(($c eq $chain)&&($ca eq "CA"))){
              	next;
              }
              #$line2=~s/^\s+//;
              	  
              	  	  my @list=split/\s+/,$line2;  #chain id
                        my $y=substr($line2,60,6);  # the value you want
                        $y=~s/^\s+//;
                        print "$y b_factor\n";
                        my $p= substr($line2,22,4) ;# pos  or aps
                        $p=~s/^0+//;
                    $p=~s/^\s+//;
                            $hash{$p}=$y;
                        }
                  
         
          
           print $out "$line                    ";
		   for(my $i=$head;$i<=$end;$i++){
				#print " $i ";
				if($hash{$i} eq " "){
					$hash{$i}=0;                       
					
				}
				if(exists $hash{$i}){
					printf $out "$hash{$i}                       ";
					
				}
				else {
					printf $out  "0                      ";
				
				}
			}
			
 	}
     
     
}     
     

























sub feature_combine(){


use IO::File;
#use strict;
#&RF_sort_hash_select();  #两两

my $m =shift;    #注意修改
my $pdb =shift;    #注意修改
my $chain =shift;   #注意修改
my $atom_pos =shift;  #注意修改
my $line2 =shift;


&funallco($m,$pdb,$chain,$atom_pos);
&funall1co($m,$pdb,$chain,$atom_pos);
#&andrew_feature_extraction();

sub funallco(){
	my $m =shift;    #注意修改
my $pdb =shift;    #注意修改
my $chain =shift;   #注意修改
my $atom_pos =shift;  #注意修改
	  print "$dir/selected_features\_$m\_xsl_apo";
	my $in1=new IO::File("<$dir/selected_features\_$m\_xsl_apo") or die "$!";  #各种金属离子训练集终选特征集特征集合
	 	 	 	 my $out1=new IO::File(">$dir/$m\_feature_combine_R.R") or die; #注意修改
	              
                   print $out1 "\n";
                   print $out1 "\n";
                   print $out1 "\n";
                   print $out1 "\n";
                   print $out1 "\n";
                   print $out1 "\n";
                   print $out1 "\n";
	 while(my $line1=<$in1>){
          chomp $line1;
          my @a=split/\s+/,$line1;
          $a[1]=~s/\"//g;
          my @b=split/\./,$a[1];
          
      print $out1 "$b[0]\=read\.table\(\"$dir\/result\_$m\_$pdb\_$chain\_$atom_pos\/$b[0]\_all\"\)\n"
       } 
       	print $out1 "\n";
	print $out1 "\n";
	print $out1 "\n";
	print $out1 "\n";
	 	seek $in1,0,0;
	 	print $out1 "cas_feature=data\.frame\(";
	 	while(my $line1=<$in1>){
          chomp $line1;
          my @a=split/\s+/,$line1;
          $a[1]=~s/\"//g;
          my @b=split/\./,$a[1];
          $b[1]=~s/V//g;
          my $list_number=$b[1]-1;
          print $out1 "$b[0]\=$b[0]\[$list_number\:$list_number\]\,";
	}
	print $out1 "\)\n";
	print $out1 "\n";
	print $out1 "\n";
	print $out1 "\n";
	print $out1 "\n";

	
	print $out1 "-cas_feature[1:3]\n";
print $out1 "new=1/(1+exp(-cas_feature))  #normlized  \n";
#print $out1 "new_ma=cbind(new,label,id)  \n";
print $out1 "write.table(new,file=\"$dir\/$m\_$pdb\_$chain\_$atom_pos\_feature_combine\",sep=\" \",row\.names=FALSE,col\.names=FALSE\)\n";  #注意修改
}

	
sub funall1co(){  #去掉cas_feature末尾，号
	   my $m =shift;    #注意修改
my $pdb =shift;    #注意修改
my $chain =shift;   #注意修改
my $atom_pos =shift;  #注意修改  	
    my $in0=new IO::File("<$dir/$m\_feature_combine_R.R") or die "$!";  #取ID   取label  #注意修改
	 	my $out0=new IO::File(">$dir/$m\_feature_combine_R_last.R") or die;   #注意修改
	while(my $line0=<$in0>){
          chomp $line0;
          if($line0 ~~/^cas_feature/){
           substr($line0,-2,1)="";	
	print "1\n";
	print $out0 "$line0\n";
}
else{
	print $out0 "$line0\n";	
}
}
}
	



#$m\_feature_combine_R_last.R  代码用R处理

   system("/usr/bin/Rscript $dir/$m\_feature_combine_R_last.R");  #注意修改 
my $in1_label=new IO::File("<$dir/$m\_$pdb\_$chain\_$atom_pos\_feature_combine") or die "$!";  #取ID   取label      #注意修改
#my $in2_label=new IO::File("<$dir/predict_PDB_SEQ") or die "$!";  #取ID   取label
my $out_label=new IO::File(">>$dir/$m\_$pdb\_$chain\_feature_combine_last") or die "$!";  #取ID   取label   #注意修改

          chomp $line2;
my @label=split/\s+/,$line2;
  my $line1=<$in1_label>;
	chomp $line1;
print $out_label "$label[0]\_$label[1]\_$label[2]\_$label[3]\_$label[4]\_$label[5]\_$label[6]\_$label[7]\_$label[8]            $line1\n";
}	
	
	
	
	
	
	  

















&predict();


sub predict(){
use warnings;
use diagnostics;
use strict;
use IO::File;
use Cwd;

&main;

sub main{
#	for my $m("Zn","Cu","Fe","Ni","Co","Ca","Mg","Mn"){    	#zhihou   zai  add "ne"  
    
	   	    my $in1=new IO::File("<$dir/predict_PDB_SEQ") or die;   #sample#input samples  list
	   my $line1=<$in1>;
          chomp $line1;
          my @tt=split/\s+/,$line1;
          my $pdb=$tt[1];
          my $chain=$tt[2];
          my $m=$tt[0];
          
          
	
		
		
		&metal_classifier($pdb,$chain,$m);  #注意修改
				
			#&metal_regression_average($m,$pdb,$chain,$atom_pos);  #注意修改
		
           
	}


	
	sub metal_classifier(){
		#my $m=shift;  #注意修改
		my $pdb=shift;  #注意修改
		my $chain=shift;  #注意修改
		my $m=shift;
		#for my $m("Zn","Cu","Fe","Ni","Co","Ca","Mg","Mn"){ 
		
		#	unless(-e "$dir/output\_$m"){    #注意修改
	#		system("mkdir $dir/output\_$m");   #注意修改
	#	}   #注意修改
		my $in1=new IO::File("<$dir/$m\_feature_combine_training") or die;
		my $n=0;
		my $line1=<$in1>;
		chomp $line1;
		my @c=split/\s+/,$line1;
		my $d=$#c;
		$n=$d-1;#(find num of the selected features )
		print"$d\n";
		&metal_xiancheng($dir,$m,$n,$pdb,$chain); #注意修改
	
	}
	
	sub metal_xiancheng(){
		my $dir=shift;
		my $m = shift;
		my $n = shift;
			my $pdb=shift;  #注意修改
		my $chain=shift;  #注意修改
		#my $atom_pos=shift;  #注意修改
		
		system("Rscript $dir/metal_predict.R $dir $m $n $pdb $chain");#注意修改
		
		
		
			my $in1=new IO::File("<$dir/$m\_$pdb\_$chain\_feature_combine_last") or die "$!";  #取ID   取label      #注意修改
my $in2=new IO::File("<$dir/output\_$pdb\_$chain/$m\.txt") or die "$!";  #取ID   取label
my $outl=new IO::File(">$dir/output\_$pdb\_$chain/$m\_predict.txt") or die "$!";  #取ID   取label   #注意修改
my $line2=<$in2>;
while(my $line1=<$in1>){
          chomp $line1;
my @label=split/\s+/,$line1;
  my $line2=<$in2>;
	chomp $line2;
	my @label2=split/\s+/,$line2;
print $outl "${label[0]}\t${label2[-1]}\n";

}

      	}
	
	
	
	sub metal_regression_average(){
		my $m=shift;
		   
		my ($max,$i,$j,@matrix);  #$i is the row,  $j is the col.   
		my @sum=();
		@matrix=();
		my @mean=();
		my $out=new IO::File(">$dir/output\_$m/$m\_result_regression_ava.txt") or die;
		
		for $j (1..3){ #100 times
			my $in=new IO::File("<$dir/output\_$m/${j}_result_regression.txt") or die;
			<$in>;
			$max=0;
			#@matrix=();  
			while(<$in>){
				$max++;
				chomp;
				my @list=split/\s+/;
				$matrix[$max][$j]=$list[-1];
				#print "$matrix[$max][$j]\n";
			}
			$in->close;
		}
		$sum[0]=0;
		for $i (1..$max){
			for $j (1..3){
				$sum[$i]=$sum[$i]+$matrix[$i][$j];
			}
			$mean[$i]=$sum[$i]/3;
			print $out "$mean[$i]\n";
		}
		$out->flush();
         $out->close;
	}
	
}	


	
	
	
	
	
	
	
	

	
	

	
	
 






































































































































     
     
     
    	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
