library(class)
library(randomForest)
library(MASS)
args<-commandArgs(TRUE)

 my_dir=args[1]     
   
 
 metal=args[2]  
 len=args[3]
 pdb=args[4]     
   
 
 chain=args[5]  

# first stage ----------------------------------------------------------------
      #train_file="/home/zc/feature_14_training.txt"

      train_file=sprintf("%s/%s_feature_combine_training",my_dir,metal) #change this directory
  		w<-read.table(train_file)
  		#test_file="/home/zc/feature_14_independent_test.txt"
  		
      test_file=sprintf("%s/%s_%s_%s_feature_combine_last",my_dir,metal,pdb,chain)
  		test<-read.table(test_file)


	for ( k in 1:1){   
			y<-w[,1]    
			#y<-as.factor(w[,1])  
			x<-data.frame(w[2:len])
			w.rf<-randomForest(x,y,ntree=500,importance=TRUE)
			t<-data.frame(test[2:len])
			w.re<-predict(w.rf,t)
			out_file=sprintf("%s/output_%s_%s/%s.txt",my_dir,pdb,chain,metal)
      #out_file=sprintf("/home/zc/output/%d_result_regression.txt",k)
			write.table(w.re,file=out_file,sep=" 	",eol="\n")
	}

